#include "main_Foot.h"


void testFoot()
	{
	Foot f(2,3,4,5,6,7);
	}

int main(int argc, char** argv)
	{
	testFoot();
	return 0;
	}
